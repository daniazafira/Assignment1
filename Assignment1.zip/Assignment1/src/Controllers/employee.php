<?php

use Slim\Http\Request; //namespace
use Slim\Http\Response; //namespace

//include employeeHr.php file
include __DIR__ . '/function/employeeHr.php';



//read table employees
$app->get('/employees', function (Request $request, Response $response, array $arg)
{
    return $this->response->withJson(array('data' => 'success'), 200);

});


//read all data from table employees
$app->get('/allemployees',function (Request $request, Response $response, array $arg)

{
    $data = getAllEmployees($this->db);

    if (is_null ($data))
    {
        return $this->response->withHeader('Access-Control-Allow-Origin', '*')->withJson(array('error' => 'no data'), 404);

    }

    return $this->response->withJson(array('data' => $data), 200);
});

//request table employees by condition (employee id)
$app->get('/employees/[{id}]', function ($request, $response, $args){
    $employeeId = $args['id'];
    if(!is_numeric($employeeId))
    {
        return $this->response->withJson(array('error' => 'numeric parameter required'), 500);
    }
    $data = getEmployees($this->db,$employeeId);
    if (empty($data))
    {
        return $this->response->withJson(array('error' => 'no data'), 500);
    }
    return $this->response->withJson(array('data' => $data), 200);
});

$app->post('/employees/add', function ($request, $response, $args)
{
    $form_data = $request->getParsedBody();
    $data = createEmployee($this->db, $form_data);
    if ($data <= 0)
    {
        return $this->response->withJson(array('error' => 'add data fail'), 500);
    }

    return $this->response->withJson(array('add data' => 'success'), 200);
}
);

//delete row
$app->delete('/employees/del/[{id}]', function ($request, $response, $args)
{
    $employeeId = $args['id'];
    if (!is_numeric($employeeId))
    {
        return $this->response->withJson(array('error' => 'numeric parameter required'), 422);
    }
    $data = deleteEmployee($this->db,$employeeId);
    if (empty($data))
    {
        return $this->response->withJson(array($employeeId=> 'is successfully deleted'), 202);

    };

});

//put table employees
$app->put('/employees/put/[{id}]', function ($request, $response, $args){
    $employeeId = $args['id'];
   
    if (!is_numeric($employeeId)){
        return $this->response->withJson(array ('error' => 'numeric parameter required'), 422);
    }

    $form_dat = $request->getParsedBody();
    $data = updateEmployee ($this->db, $form_dat, $employeeId);
    if ($data <=0)
    return $this->response->withJson(array ('data' => 'successfully updated'), 200);
});


