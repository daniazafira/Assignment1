<?php

//get all employees
function getAllEmployees($db)
{
    $sql = 'Select e.first_name, e.last_name, e.email, e.phone_number, e.salary from employees e';
    $stmt = $db->prepare ($sql);
    $stmt ->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//get employee by id
function getEmployees($db, $employeeId)
{
    $sql = 'Select e.first_name, e.last_name, e.email, e.phone_number, e.salary from employees e ';
    $sql .= 'Where e.id = :id';
    $stmt = $db->prepare ($sql);
    $id = (int) $employeeId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//add new user
function createEmployee($db, $form_data)
{
    $sql = 'Insert into employees (first_name, last_name, email, phone_number, salary) ';
    $sql .= 'values (:first_name, :last_name, :email, :phone_number, :salary)';
    $stmt = $db->prepare ($sql);
    $stmt->bindParam(':first_name', $form_data['first_name']);
    $stmt->bindParam(':last_name', $form_data['last_name']);
    $stmt->bindParam(':email', $form_data['email']);
    $stmt->bindParam(':phone_number', $form_data['phone_number']);
    $stmt->bindParam(':salary', $form_data['salary']);
    $stmt->execute();
    return $db->lastInsertID();//insert last number to continue
}

//delete employee by id
function deleteEmployee($db,$employeeId){
    $sql = ' Delete from employees where id = :id';
    $stmt = $db->prepare($sql);
    $id = (int)$employeeId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}

//update employee by id
function updateEmployee($db,$form_dat,$employeeId){
    $sql = 'UPDATE employees SET first_name = :first_name , last_name = :last_name , email = :email , phone_number = :phone_number, salary = :salary';
    $sql .=' WHERE id = :id';
    $stmt = $db->prepare ($sql);
    $id = (int)$employeeId;


    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':first_name', $form_dat['first_name']);
    $stmt->bindParam(':last_name', $form_dat['last_name']);
    $stmt->bindParam(':email', $form_dat['email']);
    $stmt->bindParam(':phone_number', $form_dat['phone_number']);
    $stmt->bindParam(':salary', $form_dat['salary']);
    $stmt->execute();

}