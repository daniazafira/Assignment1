<?php
return [
    'settings' => [
        'displayErrorDetails' => true, 
        'addCContentLengthHeader' => false,
        'upload_directory' => __DIR__ . '/../public/uploads',

     //renderer settings
     'renderer' => [
         'template_path' => __DIR__ . '/../templates',
     ],

     //database connction settings
     "db" => [
         "host" => "localhost",
         "dbname" => "hr",
         "user" => "root",
         "pass" => "",
     ]

    ],
];