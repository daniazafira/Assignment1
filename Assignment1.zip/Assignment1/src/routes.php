<?php

//hello route
require __DIR__ . '/Controllers/hello.php';

//hr routes
require __DIR__ . '/Controllers/employee.php';
